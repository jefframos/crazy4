/*
  import all the plugins to extend pixi here.
*/
import PIXI from 'pixi.js';
import AnimationLoop from 'pixi-animationloop';

export default {};
